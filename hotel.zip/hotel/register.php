<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Register | Hotel Management System</title>
 	
<!-- include takes all the text/code/markup that exists in header & db_connect.php-->

<?php include('header.php'); ?>
<?php include('admin/db_connect.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

/*
	Finding all the datas from the database
*/
$query = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
		foreach ($query as $key => $value) {
			if(!is_numeric($key))
				$_SESSION['setting_'.$key] = $value;
		}
?>

</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    /*background: #007bff;*/
	}
	main#main{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-right{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:white;
		display: flex;
		align-items: center;
	}
	#login-left{
		position: absolute;
		left:0;
		width:60%;
		height: calc(100%);
		background:#00000061;
		display: flex;
		align-items: center;
	}
	#login-right .card{
		margin: auto
	}
	.logo {
	    margin: auto;
	    font-size: 8rem;
	    background: white;
	    padding: .5em 0.8em;
	    border-radius: 50% 50%;
	    color: #000000b3;
	}
	#login-left {
	  background: url(assets/img/cover-page.jpg);
	  background-repeat: no-repeat;
	  background-size: cover;
	}
</style>

<body>


  <main id="main" class=" alert-info">
  		<div id="login-left">
  			<nav class="navbar navbar-expand-lg navbar-dark fixed-top py-3 mr-5" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="index.php"><?php echo $_SESSION['setting_hotel_name'] ?></a>
            </div>
        </nav>
  		</div>

  		<!--Login into Hotel Management system, checks for authenication-->
  		<div id="login-right">
  			<div class="card col-md-8">
  				<div class="card-body">
  					<h2 class="text-uppercase text-center text-black font-weight-bold">Register</h2>

  					<form id="login-form" method="POST" >
  						<div class="form-group">
  							<label for="username" class="control-label">Name</label>
  							<input type="text" id="name" name="Name" class="form-control" required>
  						</div>
  						<div class="form-group">
  							<label for="username" class="control-label">Username</label>
  							<input type="text" id="username" name="username" class="form-control" required>
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" id="password" name="password" class="form-control" required>
  						</div>
  							<div class="form-group">
  							<input type="hidden" id="type" name="type" value="2" class="form-control">
  						</div>
  						<center><button name="save" value="Save" class="btn-sm btn-block btn-wave col-md-4 btn-primary">Register</button></center>

  					</form>
  				</div>
  			</div>
  		</div>
   

  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<!-- <script>
$(document).ready(function() {
	$('#login-form').on('click', function() {
		$("#login-form").attr("disabled", "disabled");
		var name = $('#name').val();
		var username = $('#username').val();
		var password = $('#password').val();
		var type = $('#type').val();
		if(name!="" && username!="" && password!=""){
			$.ajax({
				url:'admin/ajax.php?action=save_user',
				method: "POST",
				data: {
					name: name,
					username: username,
					password: password,
					type: type				
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$("#login-form").removeAttr("disabled");
						$('#fupForm').find('input:text').val('');
						$("#success").show();
						$('#success').html('Data added successfully !'); 
						location.href ='admin/index.php';		
				}
					else if(dataResult.statusCode==201){
					   alert("Error occured !");
					}
					
				}
			});
		}
	});
});
</script> -->

<?php
if(isset($_REQUEST['save'])){
	$name=$_REQUEST['Name'];
	$username=$_REQUEST['username'];
	$password=$_REQUEST['password'];
	$type=$_REQUEST['type'];
	$sql = "INSERT INTO users (name,username,password,type)
	VALUES ('$name', '$username', '$password','$type')";
	if ($conn->query($sql) === TRUE) {
		$_SESSION['login_id']=$type;
		echo "<script type='text/javascript'>
		document.location.href='index.php';
		</script>";

			
	} else {
  		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	$conn->close();

}
?>
</html>